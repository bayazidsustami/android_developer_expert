object AppConfig {
    const val appId = "com.dicoding.submission.thesports"
    const val minSdk = 21
    const val targetSdk = 30
    const val versionCode = 1
    const val versionName = "1.0.0"

    const val base_url = "\"https://www.thesportsdb.com/api/v1/json/1/\""
}