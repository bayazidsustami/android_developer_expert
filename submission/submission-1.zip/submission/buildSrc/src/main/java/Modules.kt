object Modules {
    const val app = ":app"
    const val commons = ":commons"
    const val core = ":core"
}