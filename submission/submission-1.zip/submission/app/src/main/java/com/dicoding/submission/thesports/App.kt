package com.dicoding.submission.thesports

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
open class App: Application()